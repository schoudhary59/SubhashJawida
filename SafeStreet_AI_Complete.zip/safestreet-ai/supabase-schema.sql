-- SafeStreet AI — Supabase Schema
-- Run this in your Supabase SQL Editor at app.supabase.com

-- ─── ACCIDENTS (cached from Montgomery Open Data Portal) ─────────────────────
CREATE TABLE IF NOT EXISTS accidents (
  id SERIAL PRIMARY KEY,
  lat FLOAT NOT NULL,
  lng FLOAT NOT NULL,
  severity TEXT DEFAULT 'property' CHECK (severity IN ('fatal', 'injury', 'property')),
  type TEXT,
  date TIMESTAMPTZ,
  injuries INT DEFAULT 0,
  fatalities INT DEFAULT 0,
  source TEXT DEFAULT 'montgomery_open_data',
  fetched_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX accidents_location ON accidents USING gist (point(lng, lat));
CREATE INDEX accidents_date ON accidents (date DESC);

-- ─── HAZARDS (from Bright Data crawls) ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS hazards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL CHECK (type IN ('weather', 'accident', 'closure', 'construction', 'advisory')),
  severity TEXT DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  description TEXT NOT NULL,
  location TEXT,
  source TEXT,
  icon TEXT DEFAULT '⚠️',
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX hazards_active ON hazards (expires_at DESC) WHERE expires_at > NOW();

-- ─── SOS EVENTS ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sos_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  lat FLOAT NOT NULL,
  lng FLOAT NOT NULL,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'resolved', 'false_alarm', 'cancelled')),
  responders_dispatched INT DEFAULT 0,
  family_notified BOOLEAN DEFAULT FALSE,
  hospital TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

-- ─── RESPONDERS ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS responders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT UNIQUE NOT NULL,
  name TEXT,
  training TEXT[] DEFAULT '{}',
  lat FLOAT,
  lng FLOAT,
  available BOOLEAN DEFAULT TRUE,
  total_responses INT DEFAULT 0,
  registered_at TIMESTAMPTZ DEFAULT NOW(),
  last_seen TIMESTAMPTZ DEFAULT NOW()
);

-- ─── FAMILY CONTACTS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS family_contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  relationship TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ─── ENABLE REALTIME ─────────────────────────────────────────────────────────
-- In Supabase Dashboard: Database → Replication → enable for sos_events, responders

-- ─── ROW LEVEL SECURITY (Basic) ──────────────────────────────────────────────
ALTER TABLE sos_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE responders ENABLE ROW LEVEL SECURITY;

-- Public read for accidents and hazards (they're public safety data)
ALTER TABLE accidents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read accidents" ON accidents FOR SELECT USING (true);

ALTER TABLE hazards ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read active hazards" ON hazards FOR SELECT USING (expires_at > NOW());
