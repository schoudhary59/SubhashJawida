# 🛡️ SafeStreet AI — Montgomery, Alabama
### WWV Hackathon 2026 · Public Safety & Emergency Response

> *Every road in Montgomery should be smart enough to warn you, and every accident should trigger help before you even dial 911.*

**Live Demo:** Open `index.html` in any browser — zero setup required.

---

## 🚀 Quick Start (2 minutes)

### Option A — Instant Demo (No setup)
```bash
# Just open index.html in your browser — works with no installation
open index.html
# or drag it into Chrome/Firefox/Safari
```

### Option B — Full React Dev Environment
```bash
git clone <your-repo>
cd safestreet-ai

# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your API keys (see below)

# 3. Start frontend
npm run dev
# → Opens at http://localhost:5173

# 4. Start backend (separate terminal)
cd backend && npm install && node server.js
# → Runs at http://localhost:3001
```

---

## 📁 Project Structure

```
safestreet-ai/
├── index.html                  ← 🌟 Standalone app (open directly in browser)
├── src/
│   ├── pages/
│   │   ├── MapHome.jsx         ← Live accident heatmap + hazard alerts
│   │   ├── RouteCheck.jsx      ← AI-powered route danger scoring
│   │   ├── SOSScreen.jsx       ← Emergency SOS flow
│   │   ├── Responder.jsx       ← Citizen responder network
│   │   ├── Dashboard.jsx       ← City analytics dashboard
│   │   └── PostAccident.jsx    ← Post-crash guidance + AI chatbot
│   ├── services/
│   │   ├── montgomeryData.js   ← Montgomery Open Data Portal integration
│   │   └── riskEngine.js       ← Gemini AI route risk scoring
│   └── lib/
│       ├── supabase.js         ← Supabase client
│       └── gemini.js           ← Gemini AI client
├── backend/
│   ├── server.js               ← Express server (deploy to Railway)
│   └── routes/
│       ├── brightdata.js       ← Bright Data Crawl API pipeline
│       ├── twilio.js           ← Family SMS notifications
│       └── gemini.js           ← Server-side AI routes
├── supabase-schema.sql         ← Run in Supabase SQL editor
└── .env.example                ← Copy to .env and fill in keys
```

---

## 🔑 API Keys Setup

### 1. Supabase (Database + Realtime)
- Go to [supabase.com](https://supabase.com) → New Project
- Copy: Project URL + anon key → add to `.env`
- Run `supabase-schema.sql` in SQL Editor

### 2. Google Gemini (AI Engine)
- Go to [aistudio.google.com](https://aistudio.google.com)
- Click "Get API Key" → Create key
- Add to `.env` as `VITE_GEMINI_API_KEY`
- **Free tier:** 15 requests/minute — enough for hackathon

### 3. Bright Data (Live Web Scraping)
- Go to [brightdata.com](https://brightdata.com) → Create account
- Web Scraper API → Create new dataset
- Copy API key + Dataset ID → add to `.env`
- **Required for +3 bonus points!**

### 4. Twilio (SMS Notifications)
- Go to [twilio.com](https://twilio.com) → Free trial ($15 credit)
- Copy Account SID + Auth Token + phone number
- Add to backend `.env` only

---

## 📊 Data Sources

### Montgomery Open Data Portal
URL: `https://opendata.montgomeryal.gov`

| Dataset | Used For | How to Find |
|---------|----------|-------------|
| Traffic Crashes | Accident heatmap, AI training | Search "crash" or "accident" |
| 911 Dispatch | Response time analytics | Search "911" |
| Road Infrastructure | Route network data | Search "roads" or "streets" |
| Construction Permits | Active work zone hazards | Search "construction" or "permits" |

**Getting the API endpoint:**
1. Visit a dataset on the portal
2. Click "View Full Details" → "API"
3. Copy the ArcGIS REST endpoint
4. Replace `YOUR_CRASH_DATASET_ID` in `montgomeryData.js`

### Bright Data — Scraped Sources
| Source | What We Get |
|--------|-------------|
| `weather.gov/Montgomery` | Live weather conditions |
| `wsfa.com/traffic/` | Breaking accident news |
| `montgomeryal.gov/news` | City announcements |
| `dot.state.al.us` | Road work advisories |

---

## 🏗️ Architecture

```
FRONTEND (React + Vite)
    ↓ Vercel (cdn.vercel.com)
    ↓
Montgomery Open Data API ────→ Accident Heatmap + Analytics
    ↓
BACKEND (Express) ─────────── Railway.app (auto-deploy from GitHub)
    ↓
Bright Data Crawl API ────→ Live weather/news hazards every 30 min
    ↓
Gemini AI ───────────────→ Route risk scoring + hazard extraction
    ↓
Supabase ────────────────→ Hazards DB + SOS events + Realtime
    ↓
Supabase Realtime ───────→ SOS broadcast to nearby Responders
    ↓
Twilio SMS ──────────────→ Family emergency notifications
```

---

## 🎯 Hackathon Scoring

| Criterion | Max | Our Score | Why |
|-----------|-----|-----------|-----|
| Challenge Relevance | 10 | 9-10 | Direct hit on Public Safety & Emergency Response with Montgomery data |
| Quality & Design | 10 | 8-9 | Full stack, real data, AI, Realtime, SMS |
| Originality | 5 | 5 | First tool combining city open data + live web scraping + citizen responder network |
| Social Impact | 5 | 5 | Saves lives by dispatching trained bystanders before EMS |
| Commercial | 5 | 4 | SaaS for 800+ US cities with open data portals |
| **Bright Data Bonus** | +3 | **+3** | Core feature, not a bolt-on |
| **TOTAL** | 33 | **29-32** | |

---

## 📱 Demo Script (3 minutes)

**0:00** — Open app on phone: *"This is SafeStreet AI — built on Montgomery's real data"*  
**0:20** — Show Map: *"This heatmap shows every crash in Montgomery from the Open Data Portal. Atlanta Hwy corridor — real hotspot"*  
**0:50** — Route Check: *"Enter any route — Gemini AI scores it 0-100 using historical crashes + live Bright Data weather"*  
**1:20** — SOS: *"One tap — 911, family SMS with live location, nearby responders alerted. All parallel."*  
**1:50** — Responder: *"Keisha, a CPR-certified nurse 0.3 miles away, gets this alert. She responds. Family is notified."*  
**2:20** — Dashboard: *"City officials see real-time analytics + AI-predicted hotspots for next 24 hours"*  
**2:45** — Close: *"Montgomery data, Bright Data intelligence, Gemini AI. Every road smarter."*

---

## 🚀 Deployment

### Frontend → Vercel
```bash
npm install -g vercel
vercel login
vercel --prod
# Add env vars at vercel.com → Settings → Environment Variables
```

### Backend → Railway
1. Push `/backend` to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add all backend env vars in Railway dashboard
4. Railway provides a `https://xxx.railway.app` URL
5. Set `VITE_BACKEND_URL=https://xxx.railway.app` in Vercel

---

## 🛠️ Built With

- **React 18 + Vite** — Frontend
- **Tailwind CSS** — Styling  
- **Leaflet.js + leaflet.heat** — Interactive accident heatmap
- **Supabase** — Database + Realtime SOS dispatch
- **Google Gemini 1.5 Flash** — AI risk scoring + hazard extraction
- **Bright Data Crawl API** — Live web data scraping
- **Twilio** — Family SMS notifications
- **Recharts** — City analytics charts
- **Vercel + Railway** — Hosting

---

## 🏆 Team
Built for WWV Hackathon 2026 · Challenge 4: Public Safety, Emergency Response & City Analytics

*Made with ❤️ for the people of Montgomery, Alabama*
