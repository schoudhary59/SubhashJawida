// safestreet-backend/routes/twilio.js

const express = require('express');
const router = express.Router();

// ─── NOTIFY FAMILY VIA SMS ────────────────────────────────────────────────────
router.post('/notify-family', async (req, res) => {
  const { lat, lng, sosId, contacts = [] } = req.body;

  if (!process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_ACCOUNT_SID === 'your-twilio-sid') {
    console.log('📱 [MOCK] Would send SMS to', contacts.length, 'contacts');
    console.log('📍 Location:', lat, lng);
    return res.json({ sent: contacts.length, mock: true, note: 'Configure Twilio credentials for live SMS' });
  }

  const twilio = require('twilio');
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

  const mapsLink = `https://www.google.com/maps?q=${lat},${lng}`;
  const message = `🚨 SAFESTREET AI EMERGENCY ALERT

Your family member triggered an SOS in Montgomery, AL.

📍 Live location: ${mapsLink}
🆘 Incident ID: ${sosId || 'N/A'}

Help is being dispatched. Call them now.

— SafeStreet AI`;

  // In production: fetch contacts from Supabase for the user
  // const { data } = await supabase.from('family_contacts').select('phone').eq('user_id', userId)
  const phoneNumbers = contacts.length > 0 ? contacts : [];

  const results = await Promise.allSettled(
    phoneNumbers.map(phone =>
      client.messages.create({
        body: message,
        from: process.env.TWILIO_PHONE,
        to: phone,
      })
    )
  );

  const sent = results.filter(r => r.status === 'fulfilled').length;
  const failed = results.filter(r => r.status === 'rejected').length;
  console.log(`📱 SMS: ${sent} sent, ${failed} failed`);
  res.json({ sent, failed, total: phoneNumbers.length });
});

// ─── TEST SMS ─────────────────────────────────────────────────────────────────
router.post('/test', async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'phone required' });

  if (!process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_ACCOUNT_SID === 'your-twilio-sid') {
    return res.json({ success: true, mock: true, message: 'Mock SMS sent to ' + phone });
  }

  const twilio = require('twilio');
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

  try {
    await client.messages.create({
      body: '✅ SafeStreet AI test message. Your account is connected!',
      from: process.env.TWILIO_PHONE,
      to: phone,
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
