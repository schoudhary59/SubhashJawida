// safestreet-backend/routes/brightdata.js
// Full Bright Data Crawl API integration

const express = require('express');
const axios = require('axios');
const router = express.Router();

// Bright Data API client
const BD = axios.create({
  baseURL: 'https://api.brightdata.com/datasets/v3',
  headers: {
    Authorization: `Bearer ${process.env.BRIGHTDATA_API_KEY}`,
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

// URLs to crawl for Montgomery road safety intelligence
const SEED_URLS = [
  // Weather
  { url: 'https://forecast.weather.gov/MapClick.php?CityName=Montgomery&state=AL&site=BMX&textField1=32.3792&textField2=-86.3077' },
  // Local news traffic
  { url: 'https://www.wsfa.com/traffic/' },
  { url: 'https://www.waka.com/news/local/' },
  // City announcements
  { url: 'https://www.montgomeryal.gov/city-government/news' },
  // Alabama DOT
  { url: 'https://www.dot.state.al.us/bureaus/MaintenanceBureau/traffic_operations/511/' },
];

// ─── TRIGGER CRAWL ────────────────────────────────────────────────────────────
async function triggerCrawl(datasetId) {
  console.log(`📡 Triggering Bright Data crawl for ${SEED_URLS.length} URLs...`);
  const { data } = await BD.post(
    `/trigger?dataset_id=${datasetId}&include_errors=true&custom_output_fields=markdown|html2text|title`,
    SEED_URLS
  );
  console.log(`🔑 Snapshot ID: ${data.snapshot_id}`);
  return data.snapshot_id;
}

// ─── POLL PROGRESS ────────────────────────────────────────────────────────────
async function pollProgress(snapshotId, maxWaitMs = 180000) {
  const start = Date.now();
  let delay = 2000;
  let attempt = 0;

  while (Date.now() - start < maxWaitMs) {
    await new Promise(r => setTimeout(r, delay));
    attempt++;

    const { data } = await BD.get(`/progress/${snapshotId}`);
    console.log(`⏳ Attempt ${attempt}: status = ${data.status}`);

    if (data.status === 'ready') {
      console.log(`✅ Crawl ready after ${Math.round((Date.now() - start) / 1000)}s`);
      return true;
    }
    if (data.status === 'failed') {
      throw new Error(`Bright Data crawl failed: ${JSON.stringify(data)}`);
    }

    // Exponential backoff: 2s → 3s → 4.5s → ... capped at 10s
    delay = Math.min(delay * 1.5, 10000);
  }

  throw new Error(`Crawl timed out after ${maxWaitMs / 1000}s`);
}

// ─── DOWNLOAD SNAPSHOT ────────────────────────────────────────────────────────
async function downloadSnapshot(snapshotId, format = 'json') {
  console.log(`📥 Downloading snapshot ${snapshotId}...`);
  const { data } = await BD.get(`/snapshot/${snapshotId}?format=${format}`);
  return data;
}

// ─── EXTRACT HAZARDS WITH GEMINI ─────────────────────────────────────────────
async function extractHazards(scrapedData) {
  const { GoogleGenerativeAI } = require('@google/generative-ai');
  const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

  // Combine all scraped content
  const content = (Array.isArray(scrapedData) ? scrapedData : [scrapedData])
    .map(item => `SOURCE: ${item.url || 'unknown'}\n${item.markdown || item.html2text || item.content || ''}`)
    .join('\n\n---\n\n')
    .slice(0, 10000); // Token limit safety

  const prompt = `You are a road safety AI for Montgomery, Alabama.
Extract ONLY current road safety hazards from this web content.
Ignore anything unrelated to road safety, weather, or transportation.

Return ONLY a valid JSON array with no other text:
[{
  "type": "weather" | "accident" | "closure" | "construction" | "advisory",
  "severity": "low" | "medium" | "high" | "critical",
  "description": "<brief description under 100 chars>",
  "location": "<specific Montgomery location or 'Montgomery Area'>",
  "source": "<website name>",
  "icon": "<single emoji>"
}]

If no hazards found, return []

Web content:
${content}`;

  const result = await model.generateContent(prompt);
  const text = result.response.text().replace(/```json|```/g, '').trim();
  return JSON.parse(text);
}

// ─── MAIN ROUTE: TRIGGER FULL CRAWL ──────────────────────────────────────────
router.post('/crawl-hazards', async (req, res) => {
  const datasetId = process.env.BRIGHTDATA_DATASET_ID;

  if (!datasetId || !process.env.BRIGHTDATA_API_KEY) {
    // Return mock data if not configured
    return res.json({
      hazards: [
        { type: 'weather', severity: 'high', description: 'Heavy rain advisory — NWS Montgomery', location: 'Montgomery Area', source: 'weather.gov', icon: '🌧️' },
        { type: 'accident', severity: 'critical', description: 'Crash at Atlanta Hwy & Eastern Blvd — 2 lanes blocked', location: 'Atlanta Hwy & Eastern Blvd', source: 'WSFA12', icon: '🚨' },
        { type: 'construction', severity: 'medium', description: 'Lane closure I-85 N near Exit 6 until 6PM', location: 'I-85 N Exit 6', source: 'AL DOT', icon: '🚧' },
      ],
      count: 3,
      mode: 'mock',
      note: 'Configure BRIGHTDATA_API_KEY and BRIGHTDATA_DATASET_ID for live data',
    });
  }

  try {
    // Full Bright Data pipeline
    const snapshotId = await triggerCrawl(datasetId);
    await pollProgress(snapshotId);
    const rawData = await downloadSnapshot(snapshotId);
    const hazards = await extractHazards(rawData);

    // Optionally store in Supabase
    if (process.env.SUPABASE_URL && hazards.length > 0) {
      const { createClient } = require('@supabase/supabase-js');
      const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
      const expiresAt = new Date(Date.now() + 3 * 60 * 60 * 1000); // 3 hour TTL
      await supabase.from('hazards').insert(hazards.map(h => ({ ...h, expires_at: expiresAt })));
    }

    res.json({ hazards, count: hazards.length, snapshotId, crawledAt: new Date().toISOString() });
  } catch (err) {
    console.error('Crawl pipeline error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─── LIST SNAPSHOTS ───────────────────────────────────────────────────────────
router.get('/snapshots', async (req, res) => {
  const datasetId = process.env.BRIGHTDATA_DATASET_ID;
  if (!datasetId) return res.json({ snapshots: [], note: 'BRIGHTDATA_DATASET_ID not configured' });

  try {
    const { data } = await BD.get(`/snapshots?dataset_id=${datasetId}&limit=10`);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── GET CURRENT HAZARDS ─────────────────────────────────────────────────────
router.get('/hazards', async (req, res) => {
  // Fetch active hazards from Supabase (or return mock)
  try {
    const { createClient } = require('@supabase/supabase-js');
    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);
    const { data, error } = await supabase
      .from('hazards')
      .select('*')
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false });

    if (error) throw error;
    res.json({ hazards: data, count: data.length });
  } catch (err) {
    res.json({
      hazards: [
        { type: 'weather', severity: 'high', description: 'Rain advisory — reduced visibility', icon: '🌧️', source: 'NWS' },
        { type: 'accident', severity: 'medium', description: 'Fender-bender cleared on Mobile Hwy', icon: '🚗', source: 'MPD' },
      ],
      count: 2,
      mode: 'mock'
    });
  }
});

module.exports = router;
