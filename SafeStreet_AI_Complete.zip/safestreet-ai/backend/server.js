// safestreet-backend/server.js
// SafeStreet AI Backend — Deploy to Railway.app

const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json());

// ─── ROUTES ──────────────────────────────────────────────────────────────────
app.use('/api/brightdata', require('./routes/brightdata'));
app.use('/api/twilio', require('./routes/twilio'));
app.use('/api/gemini', require('./routes/gemini'));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'SafeStreet AI Backend', ts: new Date().toISOString() });
});

// ─── SCHEDULED CRAWL ─────────────────────────────────────────────────────────
// Run Bright Data crawl every 30 minutes to refresh hazard data
let crawlInterval;
if (process.env.BRIGHTDATA_API_KEY && process.env.BRIGHTDATA_API_KEY !== 'your-brightdata-api-key') {
  crawlInterval = setInterval(async () => {
    console.log('⏰ Running scheduled Bright Data crawl...');
    try {
      const res = await fetch(`http://localhost:${process.env.PORT || 3001}/api/brightdata/crawl-hazards`, {
        method: 'POST'
      });
      const data = await res.json();
      console.log(`✅ Crawl complete: ${data.count || 0} hazards extracted`);
    } catch (err) {
      console.error('❌ Scheduled crawl error:', err.message);
    }
  }, 30 * 60 * 1000); // every 30 minutes
}

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 SafeStreet AI Backend running on port ${PORT}`);
  console.log(`🌐 Bright Data: ${process.env.BRIGHTDATA_API_KEY ? '✅ Configured' : '❌ Not configured'}`);
  console.log(`📱 Twilio: ${process.env.TWILIO_ACCOUNT_SID ? '✅ Configured' : '❌ Not configured'}`);
});
