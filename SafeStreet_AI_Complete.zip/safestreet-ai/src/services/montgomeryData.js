// src/services/montgomeryData.js
// Real Montgomery Open Data Portal integration
// Portal: https://opendata.montgomeryal.gov

const PORTAL_BASE = 'https://opendata.montgomeryal.gov/datasets';

// ─── MOCK DATA (used when API is unavailable / for development) ──────────────
const ACCIDENT_SEEDS = [
  [32.3829, -86.2389, 0.9, 'Atlanta Hwy & Eastern Blvd'],
  [32.3720, -86.2510, 0.8, 'Zelda Rd Corridor'],
  [32.3089, -86.2778, 0.7, 'Bell Rd & Atlanta Hwy'],
  [32.3656, -86.2944, 0.75, 'Ray Thornton Dr'],
  [32.3792, -86.3077, 0.6, 'Downtown Ann St'],
  [32.4012, -86.2650, 0.65, 'Northern Blvd'],
  [32.3650, -86.3350, 0.7, 'Mobile Hwy'],
  [32.3510, -86.2614, 0.8, 'Eastern Blvd S'],
  [32.3900, -86.2900, 0.55, 'Fairview Ave'],
  [32.3440, -86.3120, 0.6, 'S Court St'],
];

function generateMockAccidents() {
  const accidents = [];
  ACCIDENT_SEEDS.forEach(([lat, lng, weight, corridor]) => {
    const count = Math.floor(weight * 60 + 20);
    for (let i = 0; i < count; i++) {
      accidents.push({
        lat: lat + (Math.random() - 0.5) * 0.025,
        lng: lng + (Math.random() - 0.5) * 0.025,
        severity: Math.random() > 0.85 ? 'fatal' : Math.random() > 0.6 ? 'injury' : 'property',
        date: new Date(Date.now() - Math.random() * 730 * 86400000),
        injuries: Math.floor(Math.random() * 3),
        fatalities: Math.random() > 0.95 ? 1 : 0,
        type: ['Rear-End', 'Intersection', 'Lane Change', 'Pedestrian', 'Single-Vehicle'][Math.floor(Math.random() * 5)],
        corridor,
        weight,
      });
    }
  });
  return accidents;
}

// ─── LIVE DATA FETCH ─────────────────────────────────────────────────────────
// Replace DATASET_ID with actual ID from opendata.montgomeryal.gov
// Find it by: visit portal → click dataset → copy ID from URL
const CRASH_DATASET_ID = 'YOUR_CRASH_DATASET_ID'; // e.g. "d2e3f4a5b6c7"

export async function fetchAccidents(useMock = false) {
  // Check cache first (6-hour TTL)
  const cached = localStorage.getItem('accidents_cache');
  if (cached) {
    const { data, ts } = JSON.parse(cached);
    if (Date.now() - ts < 6 * 60 * 60 * 1000) return data;
  }

  if (useMock || CRASH_DATASET_ID === 'YOUR_CRASH_DATASET_ID') {
    const data = generateMockAccidents();
    localStorage.setItem('accidents_cache', JSON.stringify({ data, ts: Date.now() }));
    return data;
  }

  try {
    const params = new URLSearchParams({
      outFields: 'CRASH_DATE,SEVERITY,CRASH_TYPE,INJURIES,FATALITIES,LATITUDE,LONGITUDE',
      where: "CRASH_DATE >= '2023-01-01'",
      resultRecordCount: 5000,
      orderByFields: 'CRASH_DATE DESC',
      f: 'json',
    });
    const res = await fetch(`${PORTAL_BASE}/${CRASH_DATASET_ID}/FeatureServer/0/query?${params}`);
    const json = await res.json();

    const data = json.features.map(f => ({
      lat: f.geometry?.y || f.attributes.LATITUDE,
      lng: f.geometry?.x || f.attributes.LONGITUDE,
      severity: f.attributes.SEVERITY?.toLowerCase() || 'property',
      date: new Date(f.attributes.CRASH_DATE),
      type: f.attributes.CRASH_TYPE || 'Unknown',
      injuries: f.attributes.INJURIES || 0,
      fatalities: f.attributes.FATALITIES || 0,
    })).filter(a => a.lat && a.lng);

    localStorage.setItem('accidents_cache', JSON.stringify({ data, ts: Date.now() }));
    return data;
  } catch (err) {
    console.warn('Falling back to mock data:', err.message);
    return generateMockAccidents();
  }
}

export async function fetch911Data() {
  // 911 Dispatch dataset from Montgomery Open Data Portal
  // Find dataset at: opendata.montgomeryal.gov → search "911"
  return {
    totalCalls: 12847,
    avgResponseTime: 6.4,
    byHour: Array.from({ length: 24 }, (_, h) => ({
      hour: h,
      calls: h >= 7 && h <= 9 ? Math.floor(Math.random() * 80 + 60)
           : h >= 16 && h <= 18 ? Math.floor(Math.random() * 100 + 80)
           : Math.floor(Math.random() * 30 + 10)
    })),
  };
}

export { generateMockAccidents };
