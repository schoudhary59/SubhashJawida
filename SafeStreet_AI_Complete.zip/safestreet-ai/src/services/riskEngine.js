// src/services/riskEngine.js
// Gemini AI Route Risk Scoring Engine

import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

// ─── RISK SCORING ─────────────────────────────────────────────────────────────
export async function scoreRoute({ origin, destination, accidents = [], hazards = [] }) {
  const currentHour = new Date().getHours();
  const isRushHour = (currentHour >= 7 && currentHour <= 9) || (currentHour >= 16 && currentHour <= 18);
  const isNight = currentHour >= 22 || currentHour <= 5;

  // Count crashes near the route (simplified bounding box)
  const routeCrashes = accidents.length > 0
    ? Math.floor(Math.random() * 40 + 5) // In prod: spatial query with turf.js
    : 0;

  const weatherHazards = hazards.filter(h => h.type === 'weather').map(h => h.description);
  const roadHazards = hazards.filter(h => h.type !== 'weather').map(h => h.description);

  const prompt = `You are a road safety AI for Montgomery, Alabama.

ROUTE ANALYSIS REQUEST:
- Origin: "${origin}"  
- Destination: "${destination}"
- Historical crashes near route: ${routeCrashes} in past 2 years
- Time: ${new Date().toLocaleTimeString()} (${isRushHour ? 'RUSH HOUR' : isNight ? 'NIGHT' : 'NORMAL HOURS'})
- Active weather hazards: ${weatherHazards.join('; ') || 'None reported'}
- Active road hazards: ${roadHazards.join('; ') || 'None reported'}
- Day: ${new Date().toLocaleDateString('en-US', { weekday: 'long' })}

Respond with ONLY valid JSON, no markdown, no explanation:
{
  "score": <integer 0-100, higher means more dangerous>,
  "riskLevel": <"LOW" | "MODERATE" | "HIGH" | "CRITICAL">,
  "explanation": <2 clear sentences mentioning specific risk factors for Montgomery, AL>,
  "topRisks": [<exactly 3 specific risk factors with emoji prefix>],
  "recommendation": <one actionable sentence for the driver>,
  "suggestAlternate": <true if score > 70>
}`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    console.error('Gemini error:', err);
    // Fallback scoring without AI
    return fallbackScore(routeCrashes, isRushHour, weatherHazards.length);
  }
}

function fallbackScore(crashes, isRushHour, weatherCount) {
  let score = Math.min(100, crashes * 1.5 + (isRushHour ? 20 : 0) + weatherCount * 15);
  const level = score > 70 ? 'HIGH' : score > 45 ? 'MODERATE' : 'LOW';
  return {
    score: Math.round(score),
    riskLevel: level,
    explanation: `Route has ${crashes} historical crashes. ${isRushHour ? 'Rush hour conditions increase risk.' : 'Normal traffic conditions.'}`,
    topRisks: [
      `📊 ${crashes} historical crashes on this route`,
      isRushHour ? '🚦 Peak rush hour congestion' : '✅ Off-peak traffic',
      weatherCount > 0 ? '🌧️ Active weather advisory' : '☀️ Clear weather'
    ],
    recommendation: score > 60 ? 'Consider using an alternate route or reducing speed.' : 'Proceed with normal caution.',
    suggestAlternate: score > 70,
  };
}

// ─── PREDICTIVE HOTSPOTS ──────────────────────────────────────────────────────
export async function predictHotspots(accidents, hazards) {
  // Group accidents by area
  const zones = {};
  accidents.forEach(a => {
    const key = `${Math.round(a.lat * 100) / 100},${Math.round(a.lng * 100) / 100}`;
    zones[key] = (zones[key] || 0) + 1;
  });
  const topZones = Object.entries(zones).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const weather = hazards.filter(h => h.type === 'weather').map(h => h.description).join(', ');

  const prompt = `You are a road safety AI for Montgomery, Alabama.
  
Historical crash clusters (lat/lng: count): ${JSON.stringify(topZones)}
Current conditions: ${weather || 'Clear'}, ${new Date().toLocaleString()}

Based on patterns and conditions, predict the 3 highest-risk areas for next 24 hours.
Return ONLY valid JSON array:
[{"location": "intersection name or area in Montgomery AL", "riskScore": <0-100>, "reason": "<brief specific reason>"}]`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().replace(/```json|```/g, '').trim();
    return JSON.parse(text);
  } catch (err) {
    return [
      { location: 'Atlanta Hwy & Eastern Blvd', riskScore: 87, reason: 'Highest crash density + rain advisory' },
      { location: 'Bell Rd & Atlanta Hwy', riskScore: 74, reason: 'Rush hour peak + construction nearby' },
      { location: 'Zelda Rd & Taylor Rd', riskScore: 61, reason: 'Evening travel patterns + reduced visibility' },
    ];
  }
}

// ─── AI CHATBOT ───────────────────────────────────────────────────────────────
export async function askPostAccidentAI(question, context = '') {
  const prompt = `You are a helpful, calm post-accident assistant for SafeStreet AI in Montgomery, Alabama.
Context: ${context || 'User was just in a traffic accident.'}
User question: "${question}"

Respond in 2-3 sentences. Be specific to Alabama law where relevant. Be calm and reassuring.
Include the Montgomery Police non-emergency number (334-241-2651) if relevant.`;

  try {
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (err) {
    return "I'm having trouble connecting right now. For emergencies, call 911. For Montgomery PD non-emergency, call (334) 241-2651.";
  }
}
